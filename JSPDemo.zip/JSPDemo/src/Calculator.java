
public class Calculator {
	
	public int getCube(int n){
		
		return n*n*n;
	}

}
